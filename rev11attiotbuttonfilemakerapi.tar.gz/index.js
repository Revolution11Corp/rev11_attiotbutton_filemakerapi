//Import environment variables 
const server = process.env.SERVER;
const database = process.env.DATABASE;
const layout = process.env.LAYOUT;
const field = process.env.FIELD;
const username = process.env.ACCOUNT;
const password = process.env.PASSWORD;

//Import required libraries
var req = require('request');

//Lambda function code

exports.handler = function(event, context, callback) {

    /*
     * This lambda sends the payload received from an AWS event (Example: IOT button)
     * To a filemaker API using token authentification
     */

    //Log the received AWS event to the console
    console.log("Event:" + JSON.stringify(event));
    //Generate base64 basic auth token:
    var auth = 'Basic ' + Buffer.from(username + ':' + password).toString('base64');

    const auth_params = {
        url: server + '/fmi/data/v1/databases/' + database + '/sessions',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': auth
        },
        rejectUnauthorized: false,
    };

    //Attempt to get authorization token from Filemaker API
    return new Promise((resolve, reject) =>{
        req.post(auth_params, function(err, res, body) {
            if (err) {
                console.log("Caught error while getting authentification from Filemaker API");
                reject(err);
            } else {
                console.log("Authentification response from server: ", body);
                
                //Handle message received from Filemaker API

                //If you successfully got an authentification token, send data to API
                console.log("Received token: " + JSON.parse(body).response.token);
                post_data(event, JSON.parse(body).response.token)
                                .then((res) =>{
                                    console.log("Posting data to Filemaker API returned: ", res);
                                    resolve(res);
                                })
                                .catch((err) =>{
                                    console.log("Caught error while posting to Filemaker API: ", err);
                                    reject(err);
                                });
            }
        });
    })
}


const post_data = (event, token) => {
    //Function that will post the event data into the correct field
    const post_params = {
        url: server + '/fmi/data/v1/databases/' + database + '/layouts/' + layout + '/records',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        },
        rejectUnauthorized: false,
        json: {
            "fieldData": {}
        }
    };
    post_params.json["fieldData"][field] = JSON.stringify(event);
    //Logs payload to console right before posting it
    console.log("Posting: " + JSON.stringify(post_params.json));

    return new Promise((resolve, reject) =>{
        //Attempts to post data to Filemaker API
        req.post(post_params, function(err, res, body) {
            if (err) {
                console.log("Error while connecting to Filemaker API:", err);
                reject(err);
            } else {
                //Data was posted, body can contain errors though
                if(JSON.parse(body)[0].message == "OK")
                    console.log("Successfully posted to Filemaker API")
                else
                    console.log("Error while posting data to  Filemaker API:", body);
                resolve(body);
            }
        });
    });
}