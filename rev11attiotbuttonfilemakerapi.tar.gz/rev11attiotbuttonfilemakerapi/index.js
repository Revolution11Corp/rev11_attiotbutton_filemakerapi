//Import environment variables 
const server = process.env.SERVER;
const database = process.env.DATABASE;
const layout = process.env.LAYOUT;
const column = process.env.COLUMN;
const username = process.env.USER;
const password = process.env.PASSWORD;

//Import required libraries
var req = require('request');
    

exports.handler = function(event, context, callback) {
    //Log the received AWS event to the console
    console.log("Event:"+JSON.stringify(event));
    //Generate base64 basic auth token:
    var auth = 'Basic ' + Buffer.from(username + ':' + password).toString('base64');
    
   const auth_params = {
       url: server + '/fmi/data/v1/databases/' + database + '/sessions',
       headers: { 'Content-Type': 'application/json',
                'Authorization':auth},
       rejectUnauthorized: false,
   };
   //Atempt to get authorization token from Filemaker API
   req.post(auth_params, function(err, res, body) {
       if(err){
           console.log(err);
       } else{
           //Success: Token is well received, now attempt to post data into the database using the received token
          console.log("Received token! "+JSON.parse(body).response.token);
          postData(event,JSON.parse(body).response.token);
       }
   });
}




var postData = function(event, token) {  
    //Function that will post the event data into the correct column
   const post_params = {
       url: server + '/fmi/data/v1/databases/' + database + '/layouts/' + layout +'/records',
       headers: { 'Content-Type': 'application/json',
       'Authorization':'Bearer '+token},
       rejectUnauthorized: false,
       json:{
           "fieldData":{
           }
       }
   };
   post_params.json["fieldData"][column]=JSON.stringify(event);
   //Logs payload to console right before posting it
   console.log("Posting : "+JSON.stringify(post_params.json));
   
   //Attempts to post data to Filemaker API
   req.post(post_params, function(err, res, body) {
       if(err){
           console.log("Error while posting data to Filemaker API:");
           console.log(err);
       } else{ 
           //Success, data was successfully posted
           console.log(body);
       }
   });
}